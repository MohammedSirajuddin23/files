package com.dl.reporting.service;

import javax.mail.MessagingException;
import javax.xml.ws.Holder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.dl.model.ConfigModel;
import com.dl.model.StatusResponse;
import com.dl.reporting.execution2005.ArrayOfString;
import com.dl.reporting.execution2005.ArrayOfWarning;
import com.dl.reporting.execution2005.ExecutionHeader;
import com.dl.reporting.execution2005.ExecutionInfo;
import com.dl.reporting.execution2005.ObjectFactory;
import com.dl.reporting.execution2005.ReportExecutionServiceSoap;

public class CustomEmailProvider 
{
	private static final Logger logger = LogManager.getLogger(CustomEmailProvider.class);

	public StatusResponse generateReport(ConfigModel config) {
		StatusResponse response = null;
		try {

			ReportExecutionServiceSoap service = new ServiceFactory().getReportExecutionService(config);
			String reportPath = config.getReportPath();

			String format = config.getEmailConfig().getEmailRenderFormat();
			String historyID = null;
			String devInfo = "<DeviceInfo></DeviceInfo>";
			Holder<byte[]> result = new Holder<>();

			Holder<String> encoding = null;
			Holder<String> mimeType = null;
			Holder<String> extension = null;
			Holder<ArrayOfWarning> warnings = null;
			Holder<ArrayOfString> streamIDs = null;

			ExecutionInfo execInfo = service.loadReport(reportPath, historyID, null, null, null);

			ObjectFactory factory = new ObjectFactory();
			ExecutionHeader executionHeader = factory.createExecutionHeader();
			executionHeader.setExecutionID(execInfo.getExecutionID());
			service.render(format, devInfo, executionHeader, null, result, extension, mimeType, encoding, warnings,
					streamIDs, null);
			logger.info("Render Service executed Successfully..");
//			logger.info("########################################" + result.value);

			new MailService().sendMail((byte[])result.value, config.getEmailConfig());
			logger.info("Custom Email Sent Successfully..");
			
			response = StatusResponse.getSuccessResponse("Report Generated successfully",null);
		} 
		catch (MessagingException e) 
		{
			response = StatusResponse.getFailedResponse("Exception in Creating Email Subscription", e);
			logger.error("Exception occured in CustomEmailProvider.generateReport() for config " + config, e);
		}
		return response;
	}
}
