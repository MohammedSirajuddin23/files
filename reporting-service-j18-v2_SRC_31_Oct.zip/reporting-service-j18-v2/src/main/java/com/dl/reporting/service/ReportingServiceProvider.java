package com.dl.reporting.service;

import com.dl.model.ConfigModel;
import com.dl.model.ServerConfig;
import com.dl.model.StatusResponse;
import com.dl.reporting.service2010.ReportingService2010Soap;

public class ReportingServiceProvider {
	private static final ReportingServiceProvider instance = new ReportingServiceProvider();
	private static ReportingService2010Soap reportingService2010;

	private ReportingServiceProvider() {
//		initiateScheduler();
	}

	public static ReportingServiceProvider getInstance(ServerConfig serverConfig) {

		reportingService2010 = new ServiceFactory().getReportingService(serverConfig);
		return instance;
	}

	public StatusResponse generateReport(ConfigModel config) {
		StatusResponse response = StatusResponse.getFailedResponse("INVALID SubscriptionType", null);
		switch (config.getSubscriptionType()) {
		case EMAIL:
			response = new EmailSubscriptionProvider().generateReport(config);
			break;
		case FILE_SHARE:
			response = new FileShareSubscriptionProvider().generateReport(config);
			break;
		case CUSTOM_EMAIL:
			response = new CustomEmailProvider().generateReport(config);
			break;
		case RENDER:
			response = new RenderProvider().generateReport( config);
			break;
		case SUB_STATUS:
			response = new SubscriptionStatusProvider().generateReport( config);
			break;
		default:
			break;
		}
		return response;
	}

//	public static void addSubscription(String subscriptionId) {
//		subscriptionList.put(subscriptionId, new Date());
//		logger.info("subscription Added: " + subscriptionId);
//		logger.info("#######SIZE: ##### " + subscriptionList.size());
//	}
//
//	private void deleteSubscription(String subscriptionId) {
//		subscriptionList.remove(subscriptionId);
//		logger.info("subscription Removed: " + subscriptionId);
//		logger.info("SIZE:  " + subscriptionList.size());
//	}
//
//	private void initiateScheduler() {
//		Logger logger2 = LogManager.getLogger(ReportingServiceProvider.class);
//		logger2.info("Scheduler Initiated");
//		// Create a scheduled executor service
//		ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
//
//		// Define a task to be executed periodically
//		Thread thread = new Thread(new Runnable() {
//			@Override
//			public void run() {
//				try {
//					logger2.info("inside Task " + subscriptionList.size());
//					Iterator<Entry<String, Date>> iterator = subscriptionList.entrySet().iterator();
//
//					while (iterator.hasNext()) {
//						Entry<String, Date> next = iterator.next();
//						String subscriptionId = next.getKey();
//						Date createdDate = next.getValue();
//						Date dateNow = new Date();
//						long timeDifferenceMillis  = dateNow.getTime() - createdDate.getTime();
//						long timeDifferenceMinutes = timeDifferenceMillis / (1000 * 60);
//						if (timeDifferenceMinutes > 1) {
//							iterator.remove();
////						deleteSubscription(subscriptionId);
//							logger2.info("Delete Subscription ");
//							reportingService2010.deleteSubscription(subscriptionId);
//						}
//					}
//				}
//
//				catch (Exception e) {
//					logger2.info("Exception ", e);
//				}
//			}
//		});
//
//		// Schedule the task to run every 5 seconds with an initial delay of 0 seconds
//		scheduler.scheduleAtFixedRate(thread, 12, 5, TimeUnit.SECONDS);
//
//	}

	public static ReportingService2010Soap getReportingservice2010() {
		return reportingService2010;
	}

	public static void setReportingService2010(ReportingService2010Soap client) {
		reportingService2010 = client;
	}
}
