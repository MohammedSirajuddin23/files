@javax.xml.bind.annotation.XmlSchema(namespace = "http://schemas.microsoft.com/sqlserver/reporting/2010/03/01/ReportServer", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.dl.reporting.service2010;
