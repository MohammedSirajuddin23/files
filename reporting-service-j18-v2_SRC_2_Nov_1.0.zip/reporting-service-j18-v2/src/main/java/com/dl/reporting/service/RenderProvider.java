package com.dl.reporting.service;

import java.util.Base64;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.ws.Holder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.dl.model.ConfigModel;
import com.dl.model.StatusResponse;
import com.dl.reporting.execution2005.ArrayOfParameterValue;
import com.dl.reporting.execution2005.ArrayOfString;
import com.dl.reporting.execution2005.ArrayOfWarning;
import com.dl.reporting.execution2005.ExecutionHeader;
import com.dl.reporting.execution2005.ExecutionInfo;
import com.dl.reporting.execution2005.ObjectFactory;
import com.dl.reporting.execution2005.ParameterValue;
import com.dl.reporting.execution2005.ReportExecutionServiceSoap;

public class RenderProvider {
	private static final Logger logger = LogManager.getLogger(RenderProvider.class);

	public StatusResponse generateReport( ConfigModel config) {
		StatusResponse response = null;
		try {

			ReportExecutionServiceSoap service = new ServiceFactory().getReportExecutionService(config);
			String reportPath = config.getReportPath();

			String format = config.getEmailConfig().getEmailRenderFormat();
			String historyID = null;
			String devInfo = "<DeviceInfo></DeviceInfo>";
			Holder<byte[]> result = new Holder<>();

			Holder<String> encoding = null;
			Holder<String> mimeType = null;
			Holder<String> extension = null;
			Holder<ArrayOfWarning> warnings = null;
			Holder<ArrayOfString> streamIDs = null;

			ExecutionInfo execInfo = service.loadReport(reportPath, historyID, null, null, null);

			ObjectFactory factory = new ObjectFactory();
			ExecutionHeader executionHeader = factory.createExecutionHeader();
			executionHeader.setExecutionID(execInfo.getExecutionID());
			
			Map<String, String> reportParameters = config.getReportParameters();
			if (reportParameters != null && !reportParameters.isEmpty())
			{
				ArrayOfParameterValue parameters = new ArrayOfParameterValue();
				List<ParameterValue> parameterValue = parameters.getParameterValue();

				Iterator<Entry<String, String>> iterator = reportParameters.entrySet().iterator();
				while (iterator.hasNext())
				{
					Entry<String, String> param = iterator.next();
					ParameterValue p1 = new ParameterValue();
					p1.setName(param.getKey());
					p1.setValue(param.getValue());
					p1.setLabel(param.getValue());
					parameterValue.add(p1);
				}
				service.setExecutionParameters(parameters, devInfo, executionHeader, null, null);
			}
			service.render(format, devInfo, executionHeader, null, result, extension, mimeType, encoding, warnings,
					streamIDs, null);
			logger.info("Render Service executed Successfully..");
//			logger.info("########################################" + result.value);
			
			response = StatusResponse.getSuccessResponse("Report Generated successfully",new String(Base64.getEncoder().encode(result.value)));
		} 
		catch (Exception e) 
		{
			response = StatusResponse.getFailedResponse("Exception in Creating Email Subscription", e);
			logger.error("Exception occured in CustomEmailProvider.generateReport() for config " + config, e);
		}
		return response;
	}
}
