package com.dl.reporting.service;
import java.util.Date;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.dl.model.EmailConfig;


public class MailService 
{
	private static final Logger logger = LogManager.getLogger(MailService.class);
	
    public  void sendMail(byte[] reportData, EmailConfig emailConfig) throws MessagingException 
    {
    	String senderEmail = emailConfig.getEmailSender();
        String recipientEmail = emailConfig.getEmailRecipient();
        String emailAttachmentName = emailConfig.getEmailAttachmentReportName();

        // SMTP server properties (change based on the server you are using)
        String smtpHost = emailConfig.getSmtpHost();
        String smtpPort = emailConfig.getSmtpPort();

        // Email subject and message
        String subject = emailConfig.getEmailSubject();
        String messageText = emailConfig.getEmailBody();

        // Create JavaMail session
        Properties props = new Properties();
        props.put("mail.smtp.host", smtpHost);
        props.put("mail.smtp.port", smtpPort);

        Session session = Session.getDefaultInstance(props);

        try {
            // Create a new email message
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(senderEmail)); // Set the sender address
            message.setRecipient(Message.RecipientType.TO, new InternetAddress(recipientEmail));
            message.setSubject(subject);

            Multipart multipart = new MimeMultipart();

            BodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setText(messageText);

            multipart.addBodyPart(messageBodyPart);

            messageBodyPart = new MimeBodyPart();
            ByteArrayDataSource source = new ByteArrayDataSource(reportData, "application/octet-stream");
            messageBodyPart.setDataHandler(new DataHandler(source));
            messageBodyPart.setFileName(emailAttachmentName); // Set the attachment file name

            multipart.addBodyPart(messageBodyPart);

            message.setContent(multipart);

            // Send the email
            Transport.send(message);
            logger.info("Email sent successfully to " + emailConfig.getEmailRecipient() + "at " + new Date());   
        } 
        catch (MessagingException e) 
        {
        	logger.error("Failed to send email to " + emailConfig.getEmailRecipient() + "at " + new Date(), e);   
        	throw e;
        }
    }
}
